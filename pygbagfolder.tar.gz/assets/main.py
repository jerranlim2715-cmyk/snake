import asyncio
import random

import pygame

pygame.init()


def spawn_apple(snake):
    while True:
        pos = (random.randrange(0, 600, 20), random.randrange(0, 600, 20))
        if not any(s.x == pos[0] and s.y == pos[1] for s in snake):
            return pos


async def main():
    screen = pygame.display.set_mode((600, 600))
    clock = pygame.time.Clock()
    score = 0
    font = pygame.font.Font(None, 24)  # built-in font works in the browser
    cell = 20
    snake = [pygame.Rect(100, 100, cell, cell)]
    direction = (0, 0)
    apple = pygame.Rect(200, 200, 20, 20)
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_w and direction != (0, 1):
                    direction = (0, -1)
                elif event.key == pygame.K_s and direction != (0, -1):
                    direction = (0, 1)
                elif event.key == pygame.K_a and direction != (1, 0):
                    direction = (-1, 0)
                elif event.key == pygame.K_d and direction != (-1, 0):
                    direction = (1, 0)

            if event.type == pygame.MOUSEBUTTONDOWN:
                dx = event.pos[0] - snake[0].centerx
                dy = event.pos[1] - snake[0].centery
                if abs(dx) > abs(dy):
                    new_dir = (1, 0) if dx > 0 else (-1, 0)
                else:
                    new_dir = (0, 1) if dy > 0 else (0, -1)
                if new_dir != (-direction[0], -direction[1]):
                    direction = new_dir

        new_head = pygame.Rect(
            (snake[0].x + direction[0] * cell) % 600,
            (snake[0].y + direction[1] * cell) % 600,
            cell,
            cell,
        )
        snake.insert(0, new_head)

        if new_head.colliderect(apple):
            score += 1
            apple.x, apple.y = spawn_apple(snake)
        else:
            snake.pop()

        for segment in snake[1:]:
            if new_head.colliderect(segment):
                running = False  # just stop the main loop

        screen.fill((0, 0, 0))
        text = font.render(f"Score: {score}", True, (255, 255, 255))
        screen.blit(text, (10, 10))
        for segment in snake:
            pygame.draw.rect(screen, (0, 200, 0), segment)
        pygame.draw.rect(screen, (255, 0, 0), apple)
        pygame.display.flip()
        clock.tick(10)
        await asyncio.sleep(0)  # give control back to the browser

    # game over screen runs after main loop ends
    screen.fill((0, 0, 0))
    game_over_text = font.render(f"Game Over! Score: {score}", True, (255, 255, 255))
    screen.blit(game_over_text, (150, 280))
    pygame.display.flip()

    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                waiting = False
        await asyncio.sleep(0)  # keep the browser responsive

    pygame.quit()


asyncio.run(main())